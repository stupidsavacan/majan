(function attachScoreCalculator(global) {
  const Sanma = global.Sanma = global.Sanma || {},
    winds = { east: 1, south: 2, west: 3, north: 4 };

  function up(v) {
    return Math.ceil(v / 100) * 100
  }

  function first(g) {
    return g && Array.isArray(g.tileTypes) ? g.tileTypes[0] || "" : ""
  }

  function parse(t) {
    let m = /^z([1-7])$/.exec(t || "");
    if (m) return { suit: "z", rank: +m[1] };
    m = /^([1-9])([mps])$/.exec(t || "");
    return m ? { suit: m[2], rank: +m[1] } : null
  }

  function terminal(t) {
    const p = parse(t);
    return !!(p && (p.suit === "z" || p.rank === 1 || p.rank === 9))
  }

  function fu(agari, yaku, c) {
    const p = agari.bestPattern,
      d = [];
    if (p.type === "kokushi" || yaku.isYakuman)
      return { fu: null, details: ["役満のため符計算を省略します。"] };
    if (p.type === "chiitoitsu")
      return { fu: 25, details: ["七対子は25符固定です。"] };
    let n = 20;
    d.push("副底 20符");
    const pinfu = yaku.yaku.some(x => x.id === "pinfu");
    if (c.winType === "ron" && c.isMenzen) {
      n += 10;
      d.push("門前ロン 10符")
    }
    if (c.winType === "tsumo" && !pinfu) {
      n += 2;
      d.push("ツモ 2符")
    }
    const pair = parse(first(p.pair));
    if (pair && pair.suit === "z") {
      if (pair.rank >= 5) {
        n += 2;
        d.push("三元牌の雀頭 2符")
      }
      if (pair.rank === winds[c.seatWind]) {
        n += 2;
        d.push("自風牌の雀頭 2符")
      }
      if (pair.rank === winds[c.roundWind]) {
        n += 2;
        d.push("場風牌の雀頭 2符")
      }
    }
    (p.melds || []).filter(x => x.kind === "triplet").forEach(x => {
      const th = terminal(first(x)),
        v = c.isMenzen ? (th ? 8 : 4) : (th ? 4 : 2);
      n += v;
      d.push(`${th?"么九牌":"中張牌"}の${c.isMenzen?"暗刻":"明刻"} ${v}符`)
    });
    if (pinfu && c.winType === "tsumo")
      return { fu: 20, details: ["平和ツモは20符です。"] };
    if (n === 20 && c.winType === "ron")
      return { fu: 30, details: d.concat("ロン和了の最低符として30符") };
    const r = Math.ceil(n / 10) * 10;
    if (r !== n) d.push(`${n}符を${r}符へ切り上げ`);
    return { fu: r, details: d }
  }

  function limit(h, f, y, r) {
    const count = y.isYakuman ? Math.max(1, y.yakuman.length) : 0;
    if (count)
      return { limitName: "役満", basePoints: 8000 * count, isYakuman: true, yakumanCount: count };
    if (h >= 13 && r.countedYakuman !== false)
      return { limitName: "数え役満", basePoints: 8000, isYakuman: true, yakumanCount: 1 };
    if (h >= 11)
      return { limitName: "三倍満", basePoints: 6000, isYakuman: false, yakumanCount: 0 };
    if (h >= 8)
      return { limitName: "倍満", basePoints: 4000, isYakuman: false, yakumanCount: 0 };
    if (h >= 6)
      return { limitName: "跳満", basePoints: 3000, isYakuman: false, yakumanCount: 0 };
    if (h >= 5 || (h === 4 && f >= 40) || (h === 3 && f >= 70))
      return { limitName: "満貫", basePoints: 2000, isYakuman: false, yakumanCount: 0 };
    return { limitName: null, basePoints: f * (2 ** (h + 2)), isYakuman: false, yakumanCount: 0 }
  }

  function payments(base, c, r) {
    const dealer = c.winnerIndex === c.dealerIndex,
      h = +c.honba || 0,
      sticks = +c.riichiSticks || 0,
      amount = up(base * (dealer ? 6 : 4)) + h * 300;
    const ron = {
      amount,
      loserIndex: c.loserIndex,
      winnerGain: amount + sticks * 1000,
      honba: h * 300,
      riichiSticks: sticks * 1000
    };
    const payers = [0, 1, 2].filter(i => i !== c.winnerIndex).map(playerIndex => {
        const pd = playerIndex === c.dealerIndex;
        let m;
        if (dealer) m = r.tsumoLoss ? 2 : 3;
        else if (pd) m = 2;
        else m = r.tsumoLoss ? 1 : 2;
        return {
          playerIndex,
          role: pd ? "dealer" : "non-dealer",
          amount: up(base * m) + h * 100
        }
      }),
      total = payers.reduce((s, p) => s + p.amount, 0);
    return {
      ron,
      tsumo: {
        payers,
        total,
        winnerGain: total + sticks * 1000,
        honbaPerPayer: h * 100,
        riichiSticks: sticks * 1000,
        policy: r.tsumoLoss ? "ツモ損あり" : "ツモ損なし"
      }
    }
  }

  function calculateScore(input) {
    const o = input || {},
      r = o.ruleConfig || {},
      a = o.agariResult || {},
      y = o.yakuResult || {},
      c = Object.assign({
        winType: "debug",
        winnerIndex: 0,
        loserIndex: 1,
        dealerIndex: 0,
        honba: 0,
        riichiSticks: 0,
        seatWind: "east",
        roundWind: "east",
        isMenzen: true
      }, o.context || {});
    if (!a.isAgari)
      return {
        isValidWin: false,
        han: 0,
        fu: null,
        isYakuman: false,
        yakumanCount: 0,
        limitName: null,
        basePoints: 0,
        payments: null,
        reason: "和了形ではありません。",
        details: []
      };
    if (!y.hasYaku)
      return {
        isValidWin: false,
        han: 0,
        fu: null,
        isYakuman: false,
        yakumanCount: 0,
        limitName: null,
        basePoints: 0,
        payments: null,
        reason: "和了形ですが役がありません。",
        details: []
      };
    const h = +y.totalHan || 0,
      F = fu(a, y, c),
      L = limit(h, F.fu, y, r),
      P = payments(L.basePoints, c, r),
      summary = L.limitName || `${h}飜${F.fu}符`;
    return {
      isValidWin: true,
      han: h,
      fu: F.fu,
      isYakuman: L.isYakuman,
      yakumanCount: L.yakumanCount,
      limitName: L.limitName,
      basePoints: L.basePoints,
      payments: P,
      reason: `${summary}として点数計算できます。`,
      details: F.details,
      context: c
    }
  }

  Sanma.ScoreCalculator = { calculateScore, roundUp100: up }
})(window);
